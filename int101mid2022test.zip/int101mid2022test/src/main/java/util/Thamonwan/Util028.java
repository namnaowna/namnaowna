package util.Thamonwan;
//3. Create a utility (public final) class named "UtilXXX" 
//   in package named "util.YYY" that contains 
//   the following "public static" fields and methods.

public class Util028 {

//    3.1. (5 points) "final double" field: YYY and set its value to XXX.9.
    public static final double THAMONWAN = 028.9;

//    3.2. (10 points) Method: computeXXXRightTriangleArea(double side1, double side2) 
//     that returns a double = ½ * side1 * side2 + XXX.8. 
//     Note that it returns XXX.99 if side1 or side2 is not a positive value.
    public static double compute028RightTriangleArea(double side1, double side2) {
        if (side1 <= 0.0 || side2 <= 0.0) {
            return 028.99;
        }
        return 1.0 / 2.0 * side1 * side2 + 028.8;
    }

//    3.3. (15 points) Method: evaluateXXX(double score) that returns a char as follow.
//     80 <= score <= 100   return A
//     70 <= score < 80     return B
//     60 <= score < 70     return C
//     50 <= score < 60     return D
//     0 <= score < 50      return E
//     otherwise            return X
    public static char evaluate028(double score) {
        if (score > 100 || score < 0) {
            return 'X';
        }
        if (score >= 80) {
            return 'A';
        }
        if (score >= 70) {
            return 'B';
        }
        if (score >= 60) {
            return 'C';
        }
        if (score >= 50) {
            return 'D';
        }
        return 'E';

    }
//    (15 points) Method: computeMagicYYY(int start, int stop, int stepOver) 
//     that returns an int result as follow.
//      - Return -1 if stop is not a positive number.
//      - result = start + (start+1) + (start+2) 
//                 + (start+3) + … + (start+z) + … + (start+stop)
//      - skip (start+z) if z is divisible by stepOver (i.e., z % stepOver == 0)
//      - return result.

    public static int computeMagicThamonwan(int start, int stop, int stepOver) {
        if (stop < 1) {
            return -1;
        }
        int result = 0;
        for (int i = 0; i <= stop; i++) {
            if (i % stepOver != 0) {
                result += start + i;
            }
        }
        return result;
    }

}

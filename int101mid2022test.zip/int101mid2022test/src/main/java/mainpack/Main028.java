
package mainpack;

import obj.Thamonwan.Obj028;
import static obj.Thamonwan.Obj028.compare;
import static util.Thamonwan.Util028.compute028RightTriangleArea;
import static util.Thamonwan.Util028.computeMagicThamonwan;
import static util.Thamonwan.Util028.evaluate028;

public class Main028 {
    public static void main(String[] args) {
        testUtil028();
        testObj028();
 
    }

    private static void testUtil028() {
        System.out.println("Compute028RightTriangleArea");
        System.out.println(compute028RightTriangleArea(20.0,30.0));
        System.out.println(compute028RightTriangleArea(-1.0,-1.0));
        
        System.out.println("Evaluate028");
        System.out.println(evaluate028(50.0));
        System.out.println(evaluate028(-1.0));
        
        System.out.println("ComputeMagicThamonwan");
        System.out.println(computeMagicThamonwan(0,10,2));
        System.out.println(computeMagicThamonwan(0,5,7));
    }

    private static void testObj028() {
        Obj028 person = new Obj028("028","Namnaow",80.0);
        System.out.println(person);
        person.setId028("060");
        System.out.println("New person Id : "+person.getId028());
        person.setNameTHAMONWAN("OHM");
        System.out.println("New person Name : "+person.getNameTHAMONWAN());
        person.setValue028(88.0);
        System.out.println("New person Value : "+person.getValue028());
        
        System.out.println("--- Compare ---");
        Obj028 p = new Obj028("007","Pond",85.0);
        Obj028 o = new Obj028("050","Aom",82.0);
        System.out.println("Compare : " + compare(o,p));
        
        System.out.println("--- Greater Than ---");

        Obj028 o1 = new Obj028("050","Aom",89.0);
        System.out.println("Greater Than : " + o.isGreaterThan(o1));



    }
    
    
}


package airconditioner;

public class AirConditioner {
    
    private int MIN_TEMPERATURE =20;
    private int MAX_TEMPERATURE =30;
    private int MAX_FAN_SPEED =2;
    private int MIN_FAN_SPEED =0;
    
    private boolean airOn;
    private boolean fanOn;
    private int targetTemperature;
    private int fanSpeed;

//    Create a constructor with two parameters: target temperature and fan speed. This
//constructor will assign values to the attributes: target temperature and fan speed.
    public AirConditioner(int targetTemperature, int fanSpeed) {
        
//        The target temperature will range between 20 and 30 Celsius(C􀁱). The fan speed can be
//0 (“low”), 1 (“medium”) or 2 (“high”). If the user enters the value greater than the maximum
//value, set the value to the maximum value. If the user enters the value lower than the minimum
//value, set the value to the minimum value.

        if(targetTemperature < 20){
            this.targetTemperature = this.MIN_TEMPERATURE;  
        }else if(targetTemperature > 30){
            this.targetTemperature = this.MAX_TEMPERATURE; 
        }else {
            this.targetTemperature = targetTemperature; 
        }
        
        if(fanSpeed < 0) {
            this.fanSpeed = this.MIN_FAN_SPEED;
        }else if(fanSpeed > 2) {
            this.fanSpeed = this.MAX_FAN_SPEED;
        }else {
            this.fanSpeed = fanSpeed;
        }
    }
    
//    The isAirOn() method will return boolean value. It returns true when the air condition is on.
//Otherwise, it returns false.
    public boolean isAirOn(){
        return airOn;
        }
    
//    The getTagetTemperature() method will return the target temperature of air conditioner in
//Celsius(C􀁱).
    public int getTagetTemperature(){
        return targetTemperature;
    }
    
//    The turnAirOnOff() method will set both airOn and fanOn attributes to true when the air
//conditioner is off. When the air conditioner is on, it will set both airOn and fanOn attributes to
//false.
    public void turnAirOnOff(){
        this.airOn = !this.airOn;
        this.fanOn = !this.fanOn;
    }
    
//    The increaseTemperature() will increase the target temperature by one. If the target
//temperature is greater than the maximum temperature, the target temperature is set to the
//maximum temperature.
    public void increaseTemperature() {
        if (this.targetTemperature + 1 >= this.MAX_TEMPERATURE) {
            this.targetTemperature = this.MAX_TEMPERATURE;
        }else {
            this.targetTemperature++;
        }
    }
    
//    The decreaseTemperature() will decrease the target temperature by one. If the target
//temperature is lower than the minimum temperature, the target temperature is set to the minimum
//temperature.
    public void decreaseTemperature(){
       if (this.targetTemperature + 1 >= this.MAX_TEMPERATURE) {
            this.targetTemperature = this.MIN_TEMPERATURE;
        }else {
            this.targetTemperature++;
        }
    }
    
//    The changeFanSpeed() will increase the fan speed by one. If the fan speed is greater than the
//maximum fan speed, the fan speed is set to the minimum fan speed.
     public void changeFanSpeed(){
         if (this.fanSpeed +1 >= this.MAX_FAN_SPEED){
             this.fanSpeed = this.MAX_FAN_SPEED;
         } else if (this.fanSpeed -1 <= this.MIN_FAN_SPEED) {
             this.fanSpeed = this.MIN_FAN_SPEED;
         }
     }

     
//     The toString() method return a string about air conditioner information as follows:
//o When air condition is off:
//Air Conditioner {Status: off}
//o When air condition is on:
//Air Conditioner {Status: on, Temp: 25, Fan: low}
@Override
    public String toString() {
        String text;
        String fanSpeedText = this.fanSpeed == 0 ? "low" : this.fanSpeed == 1 ? "medium" : "high";

        if(!this.isAirOn()){
            text = "Air Conditioner {Status: off}";
        } else {
            text = "Air Conditioner {Status: on, Temp: " + targetTemperature + ", Fan: " + fanSpeedText + "}";
        }

        return text;
    }

    public int getMIN_TEMPERATURE() {
        return MIN_TEMPERATURE;
    }

    public int getMAX_TEMPERATURE() {
        return MAX_TEMPERATURE;
    }

    public int getMAX_FAN_SPEED() {
        return MAX_FAN_SPEED;
    }

    public int getMIN_FAN_SPEED() {
        return MIN_FAN_SPEED;
    }

    public boolean isFanOn() {
        return fanOn;
    }

    public int getTargetTemperature() {
        return targetTemperature;
    }

    public int getFanSpeed() {
        return fanSpeed;
    }
     
     
     

}

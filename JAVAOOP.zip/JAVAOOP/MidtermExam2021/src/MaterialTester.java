import int101.midterm.Material;
//3. Create another class named MaterialTester, not in any package, and create a public static void main() method that does the following:
public class MaterialTester {
    
    public static void main(String[] args) {
        //3.1) Create two objects from Material class: one from each constructor. Construct the two objects with different positive values for mass, volume, and density.
        Material m1 = new Material(38.55, 50.12);
        Material m2 = new Material(3.30);
        //3.2) Print both objects out using System.out.println().
        System.out.println("m1: "+ m1);
        System.out.println("m2: "+ m2);
        //3.3) Call the mass setter on one object and call the volume setter on the other object.
        m1.setMass(10.8);
        m2.setVolume(10.9);
        //3.4) Print both objects out using System.out.println().
        System.out.println("m1: "+ m1);
        System.out.println("m2: "+ m2);
        
                
    }
}

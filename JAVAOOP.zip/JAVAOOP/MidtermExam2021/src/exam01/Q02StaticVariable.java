
package exam01;

public class Q02StaticVariable {
    //3. In the public static void main() method,
    public static void main(String[] args) {
        //3.1) let xxx be a variable of type double and set it value to be a positive number,
        double xxx = 20;
        //3.2) print the value of xxx out using System.out.println(),
        System.out.println(xxx);
        //3.3) converts xxx acres to rai and print the result out using System.out.println(),
        System.out.println(xxx +" acre = "+ convertAcreToRai(xxx) + " rai");
        //3.4) converts xxx rai to acres and print the result out using System.out.println().
        System.out.println(xxx +" rai = "+ convertRaiToAcre(xxx) + " arce");
    }
    
    //1. Define a static constant in this class to represent the following ratio: 1.0 acre = 2.529 rai.
    final static double RAI_PER_ACRE = 2.529;
    
    //2.1) a static method (convertAcreToRai) to convert an area in acres to an area in rai. This method receives an area in acres and returns an equivalent area in rai.
    public static double convertAcreToRai(double acre) {
        return acre * RAI_PER_ACRE;
    }
    
    //2.2) a static method (convertRaiToAcre) to convert an area in rai to an area in acres. This method receives an area in rai and returns an equivalent area in acres.
    public static double convertRaiToAcre(double rai) {
        return rai / RAI_PER_ACRE;
    }
    
}

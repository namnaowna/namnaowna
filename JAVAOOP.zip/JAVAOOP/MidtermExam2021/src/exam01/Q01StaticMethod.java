
package exam01;

public class Q01StaticMethod {
    
    // 2. In the public static void main() method
    
    public static void main(String[] args) {
        // 2.1) let xxx be a variable of type double and set its value to be a positive number
        double xxx = 10.0 ;
        // 2.2) print the value of xxx out using System.out.println(),
        System.out.println(xxx);
        //2.3) converts xxx meters to wah and print the result out using System.out.println(),
        System.out.println(xxx + " meters = " + convertMeterToWah(xxx) + " wah");
        //2.4) converts xxx yards to wah and print the result out using System.out.println().
        System.out.println(xxx + " yards = " + convertYardToMeter(xxx) + " meter");
        //หรือ
        double wah = convertMeterToWah(xxx);
        double meter = convertYardToMeter(xxx);
        System.out.println(xxx + " meters = " + wah + " wah");
        System.out.println(xxx + " yards = " + meter + " meter");
        
    }
    
    // 1.1) a static method (convertMeterToWah) to convert a length in meters to a length in wah where 1.0 meter = 0.5 wah (ratio). This method receives a length in meters and returns an equivalent length in wah.
    public static double convertMeterToWah(double meter){
        final double wah = 0.5;
        return meter * wah;
    }
    
    //1.2) a static method (convertYardToMeter) to convert a length in yards to a length in meters where 1.0 yard = 0.91 meter (ratio). This method receives a length in yards and returns an equivalent length in meters.
    public static double convertYardToMeter(double yard){
        final double meter = 0.91;
        return yard * meter;
    }
}

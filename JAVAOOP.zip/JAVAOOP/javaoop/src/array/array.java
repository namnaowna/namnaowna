
package array;

public class array {
    public static void main(String[] args) {
        //การสร้าง Array
        
        //แบบกำหนดขนาดเอาไว้
        int[]number = new int[5];
            //กำหนดค่าไป
            number[0] = 10;
            number[1] = 20;
            number[2] = 30;
            number[3] = 40;
            number[4] = 50;
            System.out.println("ตำแหน่งที่ 4 = "+ number[4]);
            System.out.println("จำนวนสมาชิก = "+ number.length);
            
        //แบบกำหนดสมาชิก
        int []point = {10,20,30,40};
        System.out.println("ตำแหน่งที่ 2 = " + point[2]);
        System.out.println("จำนวนสมาชิก = "+ point.length);
        
        boolean []check = {false,true,false};
        check[2] = true; //แทนค่าเข้าไปใหม่
        System.out.println("ตำแหน่งที่ 1 = " + check[1]);
        System.out.println("ตำแหน่งที่ 2 = " + check[2]);
        System.out.println("จำนวนสมาชิก = "+ check.length);
        
        String []fruit = {"กล้วย","แอปเปิล","มะละกอ","ส้ม"};
        int count = fruit.length;
        for (int i = 0; i< count ;i++){
            System.out.println(fruit[i]);
                  
        }
        System.out.println("ตำแหน่งที่ 0 = " + fruit[0]);
        System.out.println("จำนวนสมาชิก = "+ fruit.length);
            
    }
}


package javaoop;

public class Mainrun {
    public static void main(String[] args) {
        
        Programmer p1 = new Programmer(); //Create Object
        p1.setID("1");
        p1.setName("Programmer");
        p1.setSalary(14000.0);
        p1.displayEmployee();
        
        Accounting a1 = new Accounting() ;
        a1.setName("Thamonwan");
        a1.setSalary(20000.0);
        a1.displayEmployee();
        
        
        
        
//       //ใช้ Static Attribute ไม่ต้องสร้าง Object
//       System.out.println(Company.name);
//       //ใช้ Static Methods
//       Company.service();
    }
    
    
}


package javaoop;

public class Employee {
    //Atribute
    private String id;
    private String name;
    private double salary;
    //
    
    //Static Attribute เปิดให้เข้าถึงส่วนนี้ได้เลย ไม่ต้องสร้าง Object
    static int minSalary =12000;
    
    
    //Default Constructors **สร้างชื่อซ้ำกันได้
    public Employee(){
        System.out.println("I am Empolyee");
    }

    //ถ้าอยากให้มีพารามิเตอร์ใส่ค่าได้ใส่ในวงเล็บ เป็น Mutiple Constructors
    public Employee(String id ,String name ,double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }
    
  
    
    //Methods
    //Setter
    public void setID(String id){
        this.id = id;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setSalary(double salary){
        this.salary = salary;
    }
    //
    
    public void displayEmployee(){
        System.out.println("ID = "+ this.id);
        System.out.println("NAME = "+ this.name);
        System.out.println("SALARY = "+ this.salary);
    }
    
    //Getter ดึงข้อมูลออกไป
    public String getName(){
        return this.name;
    }
    
    public double getSalary() {
        return this.salary;
    }
    //
    
    
}


package javaoop;

//extends ส่งต่อคุณสมบัติ Employee มา Programmer
//สามารถใช้ Method จาก class Employee ได้
public class Programmer extends Employee {
    
    public String skill="JAVA C#";
    public Programmer(){
        System.out.println("I am Programmer");
    }
}

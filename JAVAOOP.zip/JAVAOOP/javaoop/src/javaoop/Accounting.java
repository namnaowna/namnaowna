
package javaoop;

//extends ส่งต่อคุณสมบัติ Employee มา Accounting
//สามารถใช้ Method จาก class Employee ได้
public class Accounting extends Employee {
    
    public Accounting() {
        System.out.println("I am Accounting");
    }
    
}


package javaoop;

public class Company {
    //การใช้  Static Attribute
    static String name = "Namnaow Studio";
    static String create_at = "2003";
            
    //การใช้  Static Methods
    static void service() {
        System.out.println("Programming and Game Crate");
    }
}

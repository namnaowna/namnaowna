package javaoop;

public class Main {

    public static void main(String[] args) {
        
        //ใช้ Static Attribute ไม่ต้องสร้าง Object
        int result = Employee.minSalary; //หรือ print ได้เลย System.out.println(Employee.minSalary);
        System.out.println(result);
        
        
//        //เรียกใช้ Construtors
//        Employee e1 = new Employee("1","Namnaow",20000.0); //Create Object
//        e1.displayEmployee();
//        
//        Employee e2 = new Employee("2","Ohm",30000.0); //Create Object
//        e2.displayEmployee();
        
       

            //ใช้ Getter กับ Setter
//        Employee e1 = new Employee(); //Create Object
//        e1.setID("1");
//        e1.setName("Namnaow");
//        e1.setSalary(30000.0);
////        e1.displayEmployee();
//
//        System.out.println(e1.getName());
//        System.out.println(e1.getSalary());
//
//        Employee e2 = new Employee(); //Create Object
//        e2.setID("2");
//        e2.setName("Ohm");
//        e2.setSalary(32000.0);
////        e2.displayEmployee();
//        
//        System.out.println(e2.getName());
//        System.out.println(e2.getSalary());
        
        
        
      
        
        //ใช้ public เรียกใช้โดยตรง ผ่าน Attribute
//        Employee e1 = new Employee(); //Create Object
//        e1.id ="1";
//        e1.name = "Namnaow";
//        e1.salary = 3000;
//        System.out.println("ID = "+ e1.id);
//        System.out.println("NAME = "+ e1.name);
//        System.out.println("SALARY = "+ e1.salary);
    }
}

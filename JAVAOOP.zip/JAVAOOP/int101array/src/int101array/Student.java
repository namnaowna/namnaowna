package int101array;

public class Student {

    static boolean[] allId = new boolean[10];
    int id;
    String name;

    public Student(String name) {
        this.name = name;
        //สุ่มค่า id ขึ้นมา 1 คค่าแล้วเอาไปไว้ใน static varible ชื่อ allId โดยสำรวจว่า id นี้นี้ซ้ำไหม
        do {
            id = (int) (Math.random() * 10);
        } while (allId[id]);
        allId[id] = true;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name=" + name + '}';
    }
    
}

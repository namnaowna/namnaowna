
package int101array;

public class StudentTest {
    public static void main(String[] args) {
        testStudent();
    }
    
    private static void testStudent(){
        Student[] a = new Student[10];
        for (int i = 0; i < 10 ; i++) {
            a[i] = new Student("Namnaow" + i);
            System.out.println(a[i]);
        }
        
    }
}

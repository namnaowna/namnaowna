package int101w14;

public class Person {

    private final int id;
    private String name;
    static int nextId = 0;

    public Person(int id, String name) {
        this.id = id;
        this.name = name;
        this.nextId = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Person{" + "id=" + id + ", name=" + name + '}';
    }

}

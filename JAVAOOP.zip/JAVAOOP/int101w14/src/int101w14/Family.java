
package int101w14;

public class Family {
    private Person father;
    private Person mother;
    private Person children[];
    int count;

    public Family(Person father, Person mother, Person[] children) {
        this.father = father;
        this.mother = mother;
        this.children = children;
    }

   
    
    
    
    
}




package int101array;

import java.util.Random;

public class Student {
    private static final int ID = 10; 
    private static boolean[] allIds = new boolean[ID]; //object 10 
    private int id;
    private String name;

    public Student(String name) {
        this.name = name;
        do {
            id = (new Random()).nextInt(ID);
        }while (allIds[id]);
        allIds[id] = true;
               
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name=" + name + '}';
    }
    
    
}

package int101.test;

import int101array.Student;

public class StudentTest {
    public static void main(String[] args) {
        testStudent();
    }

    private static void testStudent() {
        final int  size = 10;
        Student[] students = new Student[size]; //Create an array that holds objects.
        for (int i =0 ; i < size ; i++) {
            students[i] = new Student("No." + i); //Create an object and store it in student[] .
        }
        for (Student student : students) { // for each
            System.out.println(student);
        }
        }
    }


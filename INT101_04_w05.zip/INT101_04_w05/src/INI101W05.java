
public class INI101W05 {
    public static void main(String[] args) {
//        demoType();
//        demoOperations();
        demoMethods();
    }

    private static void demoType() {
        System.out.println("-----DemoType-----");
        boolean bl = true;
        byte by0 = 0b00001111;
        byte by1 = (byte) 0b11110000; 
        short sh0 = 0x0FFF;
        short sh1 = (short) 0xF000;
        char c = 'a';
        int i = -5;
        long ln = 7L;
        float f = 0.45F;
        double d = 0.54;
        // - left
        System.out.printf("bl= %b\nby0= {%6d}\nby1= %d\nsh0= %d\nsh1= %d\nc= %c\ni= %d\nln= %d\nf= %12.4f\nd= %f \n"
                ,bl,by0,by1,sh0,sh1,c,i,ln,f,d);
    }

    private static void demoOperations() {
        System.out.println("-----DemoOperations-----");
        int i = 0;
        System.out.println("Increment/decrement-----");
        System.out.println("i=" + i +", " + i++ + ", " + i); //i=default , i=old , i=current
        System.out.println("i=" + i +", " + i-- + ", " + i); //i=previous , i=old , i=current
        System.out.println("i=" + i +", " + --i + ", " + i); //i=previous , i=current , i=current 
        System.out.println("i=" + i +", " + ++i + ", " + i); //i=previous , i=current , i=current
        System.out.println("String Concat-----");
        System.out.println( "a" + 5 * 7); // * is more precedence +
        System.out.println(5 * 7 + "a");  // * is more precedence +
        System.out.println( "a" + 5 + 7); // + precedence is equal so left to right
        System.out.println(5 + 7 + "a");  // + precedence is equal so left to right
        System.out.println(5 + "a" + 7);  
        System.out.println( "a" + (5 + 7)); 
        
        System.out.println("Shift -----");
        int sh = 0b0111_1111_1111_1111; //0x7FFF
        System.out.printf("%d, %s , %s\n" ,
                sh , Integer.toString(sh , 16) , Integer.toString(sh, 2));
        System.out.printf("%32s \n%32s \n%32s \n%32s \n",Integer.toString(sh, 2)
        , Integer.toString(sh << 1, 2), Integer.toString(sh << 2, 2) ,  Integer.toString(sh >> 2, 2));
    }

    private static void demoMethods() {
        emptyMethod();
        int z = 20;
        int c = 5;
        withParemeter(z , c); // 20 = actual parameter
        withParemeter(z+c , c-z); // lazy evaluation but java is not this
    }
    
    private static void emptyMethod() {
        System.out.println("Hello world");
    }
    
    private static void withParemeter(int x, int y){ // x = formal parameter 
        System.out.println("x = "+ x); //Method overloding -- Name method repeatable but function is not repeat
    }
    
    private static void withParemeter(int x){ 
        System.out.println("Single x = " + x); //Method overloding
    }
    
}

package int101.array;
public class Student {
    private static final int SIZE = 10;
    private static boolean[] allIds = new boolean[SIZE];
    private int id;
    private String name;
    public Student(String name) {
        this.name = name;
        this.id = findUniqueId();
    }
    // separation of concerns
    private int findUniqueId() {
        int id;
        do {
            id = (int) (Math.random() * 10);
        } while (allIds[id]);
        allIds[id] = true;
        return id;
    }
    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name=" + name + '}';
    }
}
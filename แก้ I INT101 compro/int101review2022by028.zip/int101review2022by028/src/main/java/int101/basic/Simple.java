/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package int101.basic;

/**
 *
 * @author Student
 */
public class Simple {

    //1.1 add a private field of type string named title 
    private String title;

    //1.2 add a private field of type int named value 
    private int value;

    //1.3 add a private field of type array of double named amounts  and intialize its size to 5. 
    private double[] amounts = new double[5];

    //1.4 add a private filed of type int named count for counting  the number of elements in the amounts array. 
    private int count;

//  1.5 add a public constructor that receives a title and a value  to initializes the title and 
//  the value fields of this object.  
//   if the title parameter is null, set the title field to NOTITLE.  
//   if the value parameter is less than 0, set the value field to 0. 
    public Simple(String title, int value) {
        //this.title = title == null ? "NOTITLE" : title;
        if (title == null) {
            this.title = "NOTITLE";
        } else {
            this.title = title;
        }

        //this.value = value < 0 ? 0 : value; 
        if (value < 0) {
            this.value = 0;
        } else {
            this.value = value;

        }
    }

//    1.6 add a public method named addAmount that receives  a double parameter named amount and 
//            returns a boolean.  this method adds amount in the amounts array and  increase count by 1 
//            if the amount is larger than all elements in  the amounts array. Otherwise, it returns false  
//            and not adding anything into the array. 
    public boolean addAmount(double amount) {
        //if (count > 0 && amount <= amounts[count-1]) return false;
        for (int i = 0; i < count; i++) { //if the amount is larger than all elements in  the amounts array
            if (amount <= amounts[i]) {
                return false;
            }}
            amounts[count++] = amount; //Adds amount in the amounts array and  increase count by 1
            return true;
    }
        //1.7 override a toString method to show all the contents of this object  title, value, and each element in the amounts array. 

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append("Simple[").append("title :").append(title);
        s.append(",value: ").append(value);
        s.append(": ");
        for (int i = 0; i < count; i++) {
            s.append(" ");
            s.append(amounts[i]);
        }
        s.append(" ]");
        return s.toString();
        }
    
}

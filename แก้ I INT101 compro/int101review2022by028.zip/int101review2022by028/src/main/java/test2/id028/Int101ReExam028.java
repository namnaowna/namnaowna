/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package test2.id028;

import account.id028.*;
import int101.basic.Simple;

/**
 *
 * @author Student
 */
public class Int101ReExam028 {

    public static void main(String[] args) {
//        testPerson();
        testSimple();
    }

    private static void testPerson() {
        //2.4 Person(name)
        Person p0 = new Person("Zero");
        Person p1 = new Person("First");

        //2.5 Person::toString()
        System.out.println("Person0: " + p0);
        System.out.println("Person0: " + p1.toString());

        //2.6 Person::addAcount(userName)
        UserAccount u00 = p0.addAccount("PersonUser0");
        UserAccount u01 = p0.addAccount("PersonUser1");

        //1.8 UserAccount::toString();
        System.out.println("UserAccount00: " + u00);
        System.out.println("UserAccount00: " + u01.toString());

        System.out.println("Person0: " + p0);
    }

    private static void testSimple() {
        //Simple()
        Simple s = new Simple("SimpleTitle",-20);
        
        //Simple::addAmount()
        System.out.println("add -3.4: " + s.addAmount(-3.4));
        System.out.println("add -5.3: " + s.addAmount(-5.3));
        System.out.println("add -1.4: " + s.addAmount(-1.4));
        System.out.println("add 12.4: " + s.addAmount(12.4));
        System.out.println("add -3.4: " + s.addAmount(-3.4));


        //Simple::toString()
        System.out.println("s: " + s);
    }
    
}

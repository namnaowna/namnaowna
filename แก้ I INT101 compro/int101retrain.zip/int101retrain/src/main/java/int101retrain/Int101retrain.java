package int101retrain;

import int101.names.Naming;

public class Int101retrain {

    public static void main(String[] args) {
        Naming n = new Naming("A B");
        System.out.println(n);
        System.out.println("add XYZ: " + n.addName("XYZ") );
        System.out.println("add WWW: " + n.addName("WWW") );
        System.out.println("add URL: " + n.addName("URL") );
        System.out.println("add WWW: " + n.addName("WWW") );
        System.out.println("add ZIP: " + n.addName("ZIP") );
        
        System.out.println("Show : "+n);
        System.out.println("Find Yale : " + n.findName("Yale"));
        System.out.println("Find WWW : " + n.findName("WWW"));
        System.out.println("Remove MMM : " + n.removeName("MMM"));
        System.out.println("Remove XYZ : " + n.removeName("XYZ"));
        System.out.println("Show : "+n);        
        System.out.println("Remove XYZ : " + n.removeName("XYZ"));
        System.out.println("Show : "+n);
       

    
    }
}

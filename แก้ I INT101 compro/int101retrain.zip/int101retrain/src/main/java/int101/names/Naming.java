package int101.names;

import java.util.Arrays;

public class Naming {

    private static final int INIT_SIZE = 3;
    private static final int NOT_FOUND = -1;
    private final String title;
    private String[] names; //name.lenght | tell size
    private int count;

    private static boolean isValidNameString(String s) {
        return s != null && !s.isBlank() && !s.contains(" ");
    }

    public Naming(String title) {
        if (!isValidNameString(title)) {
            title = "NO_NAME";
        }
        this.title = title;
        this.names = new String[INIT_SIZE];
    }
    
    

    public boolean addName(String name) {
        if (!isValidNameString(name)) {
            return false;
        }
        if (findName(name)) { //Finds if this name exists in an array.
            return false;
        }
        if (count == names.length) {
            grow(); //Check if array is full? if full array is expanded using method grow()
        }
        names[count++] = name; //put name in array 1 space
//        count = count + 1;
//        count++;
        return true;
    }

        private int position(String name){ 
        if (!isValidNameString(name)) {
            return NOT_FOUND;
        }
        for (int i = 0; i < count; i++) {
            if (name.equals(names[i])) {
                return i;
            }
        }
        return NOT_FOUND;
    }

    public boolean removeName(String name) {
        int i = position(name);
        if (i == NOT_FOUND) return false;
        names[i] = names[--count];
            names[count] = null;
            return true;
//        if (!isValidNameString(name)) {
//            return false;
//        }
//        if (!findName(name)) {
//            return false;
//        }
//        for (int i = 0; i < count; i++) {
//            if (names[i].equals(name)) {
////                count = count - 1; // count--;
//                names[i] = names[--count];
//                names[count] = null;
//                return true;
//            }
//
//        }
        
    }

    public boolean findName(String name) { //Finds if this name exists in an array.
//        if (!isValidNameString(name)) {
//            return false;
//        }
//        for (int i = 0; i < count; i++) {
//            if (name.equals(names[i])) {
//                return true;
//            }
//        }
//        return false;

        return position(name) != NOT_FOUND;
    }
    
    private void grow() {
//        String[] x = new String[names.length * 2];
//        System.arraycopy(names, 0, x, 0, count);
//        names = x;
        names = Arrays.copyOf(names, count * 2);
    }

    @Override
    public String toString() {
        return "Naming{" + "title=" + title + nameList() + '}';
    }

    private String nameList() {
        if (count == 0) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append(", names=[");

        for (int i = 0; i < count; i++) {
            sb.append(" ");
            sb.append(names[i]);
        }
        sb.append(" ]");
        return sb.toString();
    }

}

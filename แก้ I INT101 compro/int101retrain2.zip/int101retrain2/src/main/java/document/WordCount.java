package document;

public class WordCount {

    private static final int NOT_FOUND = -1;
    private final String[] words = new String[INIT_SIZE];
    private final int[] frequencies = new int[INIT_SIZE];
    private int count;
    private static final int INIT_SIZE = 10;

    public boolean addWord(String word) {
        if (word == null || word.isBlank()) {
            return false;
        }
        int i = positionOf(word);
        if (i == NOT_FOUND) {
            if (count == words.length) { //Check if array is full? 
                return false;
            }
            words[count] = word;
            frequencies[count] = 1;
            count++;
            return true;

        }
        frequencies[i]++;
        return true;
    }

    private int positionOf(String word) {
        for (int i = 0; i < count; i++) {
            if (word.equals(words[i])) {
                return i;
            }

        }
        return NOT_FOUND;
    }

    @Override
    public String toString() {
        var b = new StringBuilder();
        for (int i = 0; i < count; i++) {
            b.append(words[i]);
            b.append(" ");
            b.append(frequencies[i]);
            b.append(", ");
            
        }
        return b.toString();
    }

}

package int101review1;

import human.Person;
import things.Car;
import world.Company;

public class Int101review1 {

    public static void main(String[] args) {
//        reviewLiterals();
//        testcar();
        testCompany();

    }

    static void reviewLiterals() {
        // data types : primitive type , reference type.
        boolean bl = true; // true , false
        char ch = 'q'; // 2-byte 16 bit Unicode 

        // Non-Literals
        byte by = 0b111_1111; // 1-byte 8 bit / -128 -> 127 / base-2
        short sh = 0xFF; // 2-byte 16 bit / base-16

        int i = 077; // 4-byte 32 bit / base-8
        long lng; // 8-byte 64 bit

        // floating-point number
        float f = 3453.98F; // 4-byte 32 bit / single precision
        double db = 5323.7456; // 8-byte 64 bit
        System.out.println("Character: " + by);

    }

    static void testcar() {
        Car a1 = new Car("Toyota", "BKK", "1020", 200_000.0);

        System.out.println(a1.toString());
        System.out.println("Brand : " + a1.getBrand());
        System.out.println("City : " + a1.getCity());
        System.out.println("LicemseNumber : " + a1.getLicemse_number());
        System.out.println("price : " + a1.getPrice());
        System.out.println("Increase Price : " + a1.increasePrice(20_000.0));
        System.out.println("Discount Price : " + a1.discountPrice(50_000.0));

        System.out.println("----Car new set----");

        a1.setBrand("Ford");
        a1.setCity("KornGan");
        a1.setLicemse_number("1050");
        a1.setPrice(300_000.0);
        System.out.println(a1.toString());
        System.out.println("Brand new : " + a1.getBrand());
        System.out.println("City new : " + a1.getCity());
        System.out.println("LicemseNumber new : " + a1.getLicemse_number());
        System.out.println("price new : " + a1.getPrice());
        System.out.println("Increase Price new : " + a1.increasePrice(20_000.0));
        System.out.println("Discount Price new : " + a1.discountPrice(50_000.0));
    }

    static void testCompany() {
        System.out.println("--- Company ---");
        Person person = new Person("Aom");
        System.out.println("Person : " + person);
        Company p1 = new Company("Subway","Bangbon",120_000.0,person);
        System.out.println("Company Owner : " + p1.getOwner());
        System.out.println(p1);
        System.out.println("Divident = " + p1.divident(10.0));
        System.out.println("Company : " + p1);
        
        System.out.println("--- New Company ---");
        p1.setTitle("Pizza");
        p1.setAddress("Rama2");
        p1.setCapital(10_000.0);
        p1.setOwner(new Person("Panipak"));
        System.out.println(p1);
        System.out.println("new Divident = " + p1.divident(10.0));
    }

}

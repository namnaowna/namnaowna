package things;

public class Car {

    String brand;
    String city;
    String licemse_Number;
    double price;

    public double increasePrice(double cost) { //increase price
        price = price + cost; // price += cost
        return price;
    }

    public double discountPrice(double discount) { // discount price
        price = price - discount; // price -= discount
        return price;
    }

    public Car(String barnd, String city, String licemse_number, double price) {
        this.brand = barnd;
        this.city = city;
        this.licemse_Number = licemse_number;
        this.price = price;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getLicemse_number() {
        return licemse_Number;
    }

    public void setLicemse_number(String licemse_number) {
        this.licemse_Number = licemse_number;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "car{" + "brand=" + brand + ", city=" + city + ", licemse_Number=" + licemse_Number + ", price=" + price + '}';
    }

}

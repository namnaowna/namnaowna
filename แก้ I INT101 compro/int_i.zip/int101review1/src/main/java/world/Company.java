
package world;

import human.Person;
import java.util.Objects;


public class Company {
    private String title;
    private String address;
    private double capital;
    private Person owner;

    public Company(String title, String address, double capital, Person owner) {
        this.title = title;
        this.address = address;
        this.capital = capital;
        this.owner = owner;
    }
    
    public double divident(double percent) {
//        double divident = (percent * capital) / 100.0;
//        return divident;
        return (percent * capital) / 100.0;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getCapital() {
        return capital;
    }

    public void setCapital(double capital) {
        this.capital = capital;
    }

    public Person getOwner() {
        return owner;
    }

    public void setOwner(Person owner) {
        this.owner = owner;
    }

    @Override
    public String toString() {
        return "Company{" + "title=" + title + ", address=" + address + ", capital=" + capital + ", owner=" + owner + '}';
    }

//    @Override
//    public int hashCode() {
//        int hash = 7;
//        hash = 73 * hash + Objects.hashCode(this.title);
//        hash = 73 * hash + Objects.hashCode(this.address);
//        hash = 73 * hash + (int) (Double.doubleToLongBits(this.capital) ^ (Double.doubleToLongBits(this.capital) >>> 32));
//        hash = 73 * hash + Objects.hashCode(this.owner);
//        return hash;
//    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Company other = (Company) obj;
        if (Double.doubleToLongBits(this.capital) != Double.doubleToLongBits(other.capital)) {
            return false;
        }
        if (!Objects.equals(this.title, other.title)) {
            return false;
        }
        if (!Objects.equals(this.address, other.address)) {
            return false;
        }
        return Objects.equals(this.owner, other.owner);
    }

    
    
    
}

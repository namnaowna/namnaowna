package testing;

public class MainTest {

    public static void main(String[] args) {
//        testIfStatement();
//        int x = 1;
//        testSwitchStatement("11"); // may or may not have a 'default'
        testConditionalExpression();
//        testSwitchExpression(); // must have 'default'

    }

    private static void testIfStatement() {
        var score = 4.6;
        if (score > 50.0) {
            var x = 7.6;
            System.out.println("Pass" + x);
        }
        var x = true;
        System.out.println("Finish" + x);
    }

    private static void testSwitchStatement(String x) {
//        switch (x) {
////            default ->
////                System.out.println("ERROR");
//            case "7" -> {
//                System.out.println("More");
//                System.out.println("31");
//            } 
//            case "9" -> 
//                System.out.println("28 or 29");
//        }
//        // switch
    }

    private static void testConditionalExpression() {
        var x = 5;
        var y = x > 0 ? 1 : -1; //short circit
        System.out.println("y =" + y);
    }

    private static void testSwitchExpression(int x) {
//        int result;
//        result = switch (x) {
//            case 1,3,5,7,8,10,12 -> 31;
//            case 4,6,9,11 -> 30;
//            case 2 -> 28;
//            default -> -1;
//        };
//        System.out.println(result);
    }
}

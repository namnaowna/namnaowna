// Non object 
public class HelloWorld {
    public static void main(String[] args) {
        double c , i; // declaration
        c = 5.0; // assignment , initialization(first)
        i = convertCentimeterToInch(c);
        System.out.println("");
    }
 
    public static double convertCentimeterToInch(double centimeter) {
        //body of this function
        double inch;
        inch = centimeter / 2.5; //operator +  -  *  / %
        return inch;
    }
}


package int101w13.random;

import java.util.Random;

public class DigitRandom {
    private static Random r = new Random(); 
    public static int rand() {
//        return Math.random() < 0.75; // [0 .. 0.5) [0.5 .. 1) retrun type boolean
//        return (int)(Math.random() * 10); // [0,0.1) , [0.1,0.2) ..., [0.9,1)
        return r.nextInt(10);
    }
}


package int101w13;

import int101w13.random.DigitRandom;

public class Int101w13Main {
    public static void main(String[] args) {
        testDigitRandom();
    }

    private static void testDigitRandom() {
        final int loop = 1_000_000;
        final int digit = 10;
        int[] count = new int[digit]; // array
        for (int i = 0; i < loop ; i++) {
            count[DigitRandom.rand()]++;
        }
//        for (int i = 0; i < digit ; i++) {
//            System.out.println( count[i] / (double) loop);
//        }
        for (int c : count) { //for each in the collection/array
            System.out.println( c / (double) loop);
        }
        
        
    }
}

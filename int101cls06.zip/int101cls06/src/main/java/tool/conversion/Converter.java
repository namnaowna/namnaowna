package tool.conversion;

/**
 * This is a generic converter. Each converter object has a name and a ratio for
 * conversion. Each converter can convert from and to between two units, e.g.,
 * inch to cm and cm to inch.
 *
 * @author KriengkraiPorkaew
 */
public class Converter {

    /**
     * <code>name</code> is the name of the converter. The client should give a
     * meaningful name.
     */
    private final String name;

    /**
     * <code>ratio</code> is the ratio that uses for conversion.
     */
    private final double ratio;

    // constructor
    public Converter(String name, double ratio) {
        this.name = name == null ? "Noname" : name;
//        if (name == null) {
//            this.name = "Noname";
//        } else {
//            this.name = name;
//        }

        this.ratio = ratio > 0 ? ratio : 1.0;
    }

    public Converter(double ratio) {
        this(null, ratio);
    }

    // getters
    public String getName() {
        return name;
    }

    public double getRatio() {
        return ratio;
    }

    @Override
    public String toString() {
        return "Converter{" + "name=" + name + ", ratio=" + ratio + '}';
    }

    public double convert(double source) {
        return source * ratio;
    }

    public double invert(double target) {
        return target / ratio;
    }

}

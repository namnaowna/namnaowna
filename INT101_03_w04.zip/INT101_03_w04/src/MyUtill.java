
public class MyUtill {
    private final double CM_PER_INCH = 2.54;
    private final double LB_PER_KG = 2.20;
    
    public static double convertInchToCm(double inch) {
        double y = 10;
        double x = y++;
        
        x += 5; // x = x + 5
        x -= 5; // x = x - 5
        x *= 5; // x = x * 5
        
        return 0;
    }
}

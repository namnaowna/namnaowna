
public class Person {
    private long id;
    private boolean Male; // M = male , F = female --case 2 sex is male and female 
    private String name; 
    private Person mom;

    public long getId() { //getter // design name type camelCase
        return id;
    }

    public boolean isMale() { 
        return Male;
    }

    public String getName() {
        return name;
    }

    public Person getMom() {
        return mom;
    }

    public void setName(String name) { // setter //shadow
        this.name = name;
    }
    
}

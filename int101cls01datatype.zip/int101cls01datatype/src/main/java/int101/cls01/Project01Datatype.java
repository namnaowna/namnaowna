package int101.cls01;

public class Project01Datatype {
   public static void main(String[] args) {
      System.out.println("## Project#01 Data Types ========== ==========");
      // https://docs.oracle.com/javase/tutorial/java/nutsandbolts/datatypes.html

      /*
      java has 2+1 groups of types: 
      * primitive types (8 types): 
        ** boolean type: <boolean>
        ** numeric type (for arithmetic operations)
           *** integral types (for bitwise operations):
               **** signed integers: <byte>, <short>, <int>, <long>
               **** unsigned integer: <char> (also represent characters)
           *** floating-point types (2 types): <float>, <double>
      * reference type, and 
      * (special, no name) null type.
      */
      demo01Boolean();
      demo02Integral();
      demo03Character();
      demo04FloatingPoint();
      demo05ReferenceAndNull();
   }

   private static void demo01Boolean() {
      System.out.println("\n## Demo01 Primitive Type: boolean ==========");
      // true and false are literal forms of the only two possible values.
      boolean t = true;
      boolean f = false;
      System.out.println("There are two possible values: <" + t + "> and <" + f + ">.");
      System.out.printf("  use %%b and %%B for formatting: <%b> <%B>.\n", t, t);
   }

   private static void demo02Integral() {
      System.out.println("\n## Demo02 Integral Types: byte, short, char, int, long ==========");
      /*
      integral types: represent whole numbers.
      * byte = 8-bit integer: 256 possible values (2^8): -128 (-2^7), ..., 0, ..., 127
      * short = 16-bit integer: 2^16 possible values: -32768 (-2^15), ..., 32767 (2^15 - 1)
      * char = 16 bit unsigned integer: 2^16 possible values: 0, 1, ..., 65535
      * int = 32-bit integer: 2^32 possible values: 2147483648 (-2^31) [2 billions], ..., 2^31 - 1
      * long = 64-bit integer: 2^64 possible values: 9.22 * 10^18 [+/- 9 billion billions]
      */

      // integral literal forms: 0b (binary), 0 (octal), 0x (hexadecimal) 
      byte by = 0b00001111; // start with 0b or 0B for binary form
      short sh = 077; // start with 0 for octal form
      char ch = 65; // start with any number except 0 for decimal form
      int i = 0xFF; // start with 0x or 0X for hexadecimal form
      long lng = 987_654_321_000L; // end with l or L for long
      // _ can be used anywhere in the middle for all literal forms
      System.out.println("byte: " + by + " = binary: " + Integer.toBinaryString(by));
      System.out.println("short: " + sh + " = octal: " + Integer.toOctalString(sh));
      System.out.println("char: " + ch + " = number: " + (ch+0));
      System.out.println("int: " + i + " = hexadecimal: " + Integer.toHexString(i));
      System.out.println("long: " + lng);
      System.out.printf("formatting integer: %o (octal), %d (decimal), %x (hex), %X (HEX).\n", 
         i, i, i, i);
   }

   private static void demo03Character() {
      System.out.println("\n## Demo03 char type (Unsigned Integer and Unicode Character) ==========");
      // char for 16-bit unsigned integer and unicode character
      // char literal forms: numberic, '\\uXXXX' (unicode), 'A' (character)
      char x = 0x61; // = 'a' (literal in hexadecimal form) 
      char b = 0b01100010; // = 'b' (literal in binary form)
      char c = 'c'; // = 'c' (literal in character form)
      char n = 100; // = 'd' (literal in decimal form)
      char u = '\u0065'; // = 'e' (literal in unicode form)
      System.out.println("char: " + x + ", " + b + ", " + c + ", " + n + ", " + u);
      System.out.printf("format: %c, %C (CAP), %d (decimal), %x (hex), %o (octal).\n", x, x, x+0, x+0, x+0);
   }

   private static void demo04FloatingPoint() {
      System.out.println("\n## Demo04 Floating-Point Types:  ==========");
      /*
      floating-point types: represent decimal numbers.
      * float = 32-bit floating-point number: range +/- 2^128 [+/- 3.4 * 10^38]
      * double = 64-bit floating-point number: range +/- 2^1024 [+/- 1.8 * 10^308]
      */

      // floating-point literal forms: simple and scientific notations
      double d = 1_234_567.890_123_4; // _ can be anywhere in the middle
      double e = 1.23e-2; // e or E for scientific notation
      float f = 1_234.5678f; // end with f or F for float
      System.out.println("double: " + d);
      System.out.println("float: " + f);
      System.out.printf("formatting floating-point: %f, %e (scientific), %g (f/e).\n", 
         e, e, e); // %g represents the shorter form between %f and %e
   }
   
   private static void demo05ReferenceAndNull() {
      System.out.println("\n## Demo05 Reference Type and Null Type:  ==========");
      /*
      There is only one possible value for null type, which is <null>.
      Null type has no name.
      It is impossible to declare a variable of null type.
      */

      String s; // s is a variable of reference type for storing a reference to a String object.
      s = null; // Null type can be cast to any reference type.
      Object o = null;
      System.out.println("Null Type:");
      System.out.println("s = <" + s + ">.");
      System.out.println("o = <" + o + ">.");
      s = "some string";
      o = "some string";
      System.out.println("String object:");
      System.out.println("s = <" + s + ">.");
      System.out.println("o = <" + o + ">.");
      
      /*
      All reference types are for storing a reference to an object.
      An object can be created from a class, an interface, or an array.
      */
   }
}


package set1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SetExample {
    public static void main(String[] args) {
//        Set<String> names = new HashSet<>();
//        names.add("Best");
//        names.add("Test");
//        names.add("John");
//        names.add("Best");
//        
//        System.out.println(names);
          List<String> fruits = new ArrayList<>(Arrays.asList("durian","banana","orange","apple","banana"));
          Set<String> hashSet = new HashSet<>();
          Set<String> linkedSet = new LinkedHashSet<>();
          Set<String> treeSet = new TreeSet<>();
          
          System.out.printf("HashSet: %s%n",hashSet);
          System.out.printf("LinkedHashSet: %s%n",linkedSet);
          System.out.printf("TreeSet: %s%n",treeSet);


        }
    }


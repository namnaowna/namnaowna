
package enum1;

public enum UserStatus {
    ACTIVE , BLOCKED , INACTIVE
}

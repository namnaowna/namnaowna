
package enum1;

public class Test {
    public static void main(String[] args) {
        User u1 = new User("Username 1",UserStatus.ACTIVE);
        User u2 = new User("Username 2",UserStatus.INACTIVE);
        User u3 = new User("Username 2",UserStatus.BLOCKED);
        
        System.out.println(UserStatus.valueOf("INACTIVE"));
        
        System.out.println(u1.getStatus().equals(UserStatus.ACTIVE) ? u1.getUsername() : "");
        System.out.println(u2.getStatus().equals(UserStatus.ACTIVE) ? u2.getUsername() : "");
        System.out.println(u3.getStatus().equals(UserStatus.ACTIVE) ? u3.getUsername() : "");
        
        System.out.println(u1.getStatus().equals(UserStatus.valueOf("ACTIVE")) ? u1.getUsername() : "");
        System.out.println(u2.getStatus().equals(UserStatus.valueOf("ACTIVE")) ? u2.getUsername() : "");
        System.out.println(u3.getStatus().equals(UserStatus.valueOf("ACTIVE")) ? u3.getUsername() : "");
    }
}
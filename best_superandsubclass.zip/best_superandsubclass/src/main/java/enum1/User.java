
package enum1;

public class User {
    private String username;
    private UserStatus status;

    public String getUsername() {
        return username;
    }

    public UserStatus getStatus() {
        return status;
    }

    public User(String username, UserStatus status) {
        this.username = username;
        this.status = status;
    }
}




package comparetor_comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparatorExample {
    public static void main(String[] args) {
        List<Item> items = new ArrayList<>();
        items.add(new Item("Water","Drinks",10F,100));
        items.add(new Item("Lays","Snacks",22.5F,20));
        items.add(new Item("Chocolate","Sancks",55.55F,50));
        items.add(new Item("Pencil","Tools",13.25F,1000));
        items.add(new Item("Paper","Tools",2.5F,10000));
        items.add(new Item("Coke","Drinks",18F,20));
        
        Collections.sort(items); //Comparable
        
//        items.sort(new Comparator<Item>() { //Comparator
//            @Override
//            public int compare(Item o1, Item o2) {
////                return o1.getName().compareTo(o2.getName()); //ascending word
////                return -o1.getName().compareTo(o2.getName()); //descending word
////                return (int) (o1.getPrice() - o2.getPrice()); //ascending number
//                return (int) -(o1.getPrice() - o2.getPrice()); //descending number
//
//            }
//        });
//        
        for (Item item : items) { //Show list
            System.out.printf("Name: %s , Category: %s, Price: %.2f ,Stock: %d%n",
                    item.getName() , item.getCatgory() , item.getPrice() ,item.getStocks());
        }
    }
    
}

class Item implements Comparable<Item> {
    private String name;
    private String catgory;
    private float price;
    private int stocks;

    public Item(String name, String catgory, float price, int stocks) {
        this.name = name;
        this.catgory = catgory;
        this.price = price;
        this.stocks = stocks;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCatgory() {
        return catgory;
    }

    public void setCatgory(String catgory) {
        this.catgory = catgory;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getStocks() {
        return stocks;
    }

    public void setStocks(int stocks) {
        this.stocks = stocks;
    }

    @Override
    public int compareTo(Item o) { //Comparable
        // sort by category first then sortby name
        if(this.getCatgory().equalsIgnoreCase(o.getCatgory())) {
            return this.getName().compareToIgnoreCase(o.getName());
        }
        return this.getCatgory().compareTo(o.getCatgory());
    }

    
    
}

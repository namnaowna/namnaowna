
package test;

public class Abstract1 {
    public static void main(String[] args) {
        Greeting g1 = new Greeting();
        g1.sayHi();
        g1.sayHello();
    }
}

abstract class Abstract {
    public void sayHello() {
        System.out.println("Hello");
    }
    
    public abstract void sayHi();
}

class Greeting extends Abstract {

    @Override
    public void sayHi() {
        System.out.println("Say hi");
    }
    
}


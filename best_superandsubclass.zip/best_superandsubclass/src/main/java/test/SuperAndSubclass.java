package test;

public class SuperAndSubclass {

    public static void main(String[] args) {
        Car c1 = new Car("Ford", "Mustang");
        c1.sound();
        
        Airplane a1 = new Airplane("Nokair",2003);
        a1.sound();
    }
}

class Venicle {

    private String brand;

    public Venicle(String brand) {
        this.brand = brand;
    }

    public void sound() {
        System.out.println("Tid tid");
    }

}

class Car extends Venicle {

    private String model;

    public Car(String brand, String model) {
        super(brand);
        this.model = model;
    }

    @Override
    public void sound() {
        System.out.println("Tud tud");
    }

}

class Airplane extends Venicle {

    private int year;

    public Airplane(String brand, int year) {
        super(brand);
        this.year = year;

    }
    
//    @Override
//    public void sound() {
//        System.out.println("Flush flush");
//    }
    

}

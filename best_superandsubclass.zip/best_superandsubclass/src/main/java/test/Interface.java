package test;

public class Interface {

    public static void main(String[] args) {
//        Mobile m1 = new Mobile();
//        m1.call();
//        m1.capture();
//        m1.hangup();
//        
//        RichMobile r = new RichMobile();
//        r.call();
//        r.capture();
//        r.hangup();
//        r.track();

        RichMobileByExtend r1 = new RichMobileByExtend();
        r1.call();
        r1.capture();
        r1.hangup();
        r1.track();
    }
}

interface Gps {

    public void track();
}

interface Camera {

    public void capture();
}

interface Phone {

    public void call();

    public void hangup();
}

class Mobile implements Phone, Camera {

    @Override
    public void call() {
        System.out.println("Mobile call");
    }

    @Override
    public void hangup() {
        System.out.println("Mobile hangup");

    }

    @Override
    public void capture() {
        System.out.println("Mobile capture");

    }

}

class RichMobile implements Gps, Camera, Phone {

    @Override
    public void track() {
        System.out.println("RichMobile track");
    }

    @Override
    public void capture() {
        System.out.println("RichMobile capture");
    }

    @Override
    public void call() {
        System.out.println("RichMobile call");
    }

    @Override
    public void hangup() {
        System.out.println("RichMobile hangup");
    }

}

class RichMobileByExtend extends Mobile implements Gps {

    @Override
    public void track() {
        System.out.println("RichMobileByExtend track");
    }

}

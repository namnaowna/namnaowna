
package generictype1;

public class GenericExample {
    public static void main(String[] args) {
        MyList<Ball> balls = new MyList<>();
        MyList<Table> tables = new MyList<>();
        
        balls.add(new Ball("RED"));
        balls.add(new Ball("BLUE"));
        balls.add(new Ball("GREEN"));
        
        tables.add(new Table(1));
        tables.add(new Table(2));
        tables.add(new Table(3));
        
        System.out.println(balls.get(2));
        System.out.println(tables.get(2));
    }
}

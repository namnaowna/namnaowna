
package generictype1;

public class MyList<T> {
    private T[] items;
    private int size;

    public MyList() {
        this.items = (T[]) new Object[10];
        this.size = 0;
    }
    
    public void add(T item) {
        if (size == items.length) {
            System.out.println(item.getClass().getSimpleName() + " List is FULL");
            return;
        }
        items[size] = item;
        size++;
    }
    
    public T get(int index) {
        if (index < 0) {
            System.out.println("Index not found");
            return null;
        }
        if (index >= size) {
            System.out.println("Index not found");
            return null;
        }
        return items[index];
    }
}

class Ball {
    private String color;

    public Ball(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    @Override
    public String toString() {
        return "Ball{" + "color=" + color + '}';
    }
    
}

class Table {
    private int id;

    public Table(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Table{" + "id=" + id + '}';
    }
    
}
    
package nested;

public class NestedClass {

    public static void main(String[] args) {
        Outer.Inner inner = new Outer().new Inner(); //new Outer.Inner()
        inner.sayHello();

        Animal cat = new Animal();
        cat.sound();

//        anonymous
        Animal giant = new Animal() {
            @Override
            public void sound() {
                System.out.println("Frush frush");
            }

        };
        giant.sound();
        
    }
}

    class Animal {

        public void sound() {
            System.out.println("Meow meow");
        }
    }

    class Outer {

        class Inner {

            public void sayHello() {
                System.out.println("Hello world");
            }
        }
    }



package queue1;

import java.util.LinkedList;
import java.util.Queue;

public class PriorityQueue {
    //Concept FIFO (First in first out) , FCFS
    public static void main(String[] args) {
        Queue<String> queues = new LinkedList<>();
        queues.offer("1th");
        queues.offer("2th");
        queues.offer("3th");
        queues.offer("4th");
        
        
        System.out.println(queues);
        
        System.out.println(queues.peek());
        
        System.out.println(queues.poll()); //remove firt order
        System.out.println(queues);
        
        System.out.println(queues.remove("3th"));
        System.out.println(queues);
        
        
    }
}

package porkaew.conditional;

public class Int101cls07conditional {

    public static void main(String[] args) {
        demo01IfStatement();
        demo02IfElseStatement();
        demo03NestedIfStatement();
        demo04SwitchCaseStatement();
        demo05SwitchCaseExpression();
        demo06ConditionalExpression();
    }
    
    private static void demo01IfStatement() {
       System.out.println("\nDemo01 If Statement ===============");
       // if (BOOLEAN_EXPRESSION) statement;
       // if (BOOLEAN_EXPRESSION) { BLOCK }
       
       // BOOLEAN EXPRESSION ==> 
       //   boolean operations: &&, || (short-circuit); &, |, !
       //   relational operations: <, >, <=, >= (numeric types); ==, != (all types)
       //   method invocations returning boolean values: e.g., .equals()
       var a = 1;
       var b = 2;
       if (a < b) System.out.printf("a(%d) < b(%d)\n", a, b);
       if (a > b) System.out.printf("a(%d) < b(%d)\n", a, b);
       if (a != b) System.out.printf("a(%d) != b(%d)\n", a, b);
       if (a == b) System.out.printf("a(%d) == b(%d)\n", a, b);
    }
    private static void demo02IfElseStatement() {
       System.out.println("\nDemo02 If-Else Statement ===============");
       // if (BOOLEAN_EXPRESSION) 
       //    STATEMENT_OR_BLOCK_FOR_TRUE;
       // else
       //    STATEMENT_OR_BLOCK_FOR_FALSE;
       var a = 'x';
       var b = 'Y';
       if (a < b) {
          System.out.printf("a(%c) < b(%c)\n", a, b);
       } else {
          System.out.printf("a(%c) >= b(%c)\n", a, b);
       }
    }
    private static void demo03NestedIfStatement() {
       System.out.println("\nDemo03 Nested If Statement ===============");
       // if (BOOLEAN_EXPRESSION_1)
       //    if (BOOLEAN_EXPRESION_2)
       //       STATEMENT_OR_BLOCK_FOR_1_TRUE_AND_2_TRUE
       var a = 1.9999_9999_9999_9999;
       var b = 2.0000_0000_0000_0000;
       if (a < b) {
          System.out.printf("a(%.20f) < b(%.20f)\n", a, b);
       } else if (a > b) {
          System.out.printf("a(%.20f) > b(%.20f)\n", a, b);
       } else {
          System.out.printf("a(%.20f) == b(%.20f)\n", a, b);
       }
          
    }
    private static void demo04SwitchCaseStatement() {
       System.out.println("\nDemo04 Switch-Case Statement ===============");
       
       // switch-case statement: COLON CASE
       // switch (EXPRESSION) {
       //    case CONSTANT_EXPRESSION :
       //       STATEMENTS;
       //       break; // execution will continue until "break" or end of "switch" 
       //    default : // "default" is optional and need not be the last one
       //       STATEMENTS; // the last case needs no break
       // }
       var m = 8;
       switch (m) {
          case 1 : // this case share execution with the next one
          case 8 :
             System.out.printf("Month %d has the same number of days as the previous month.\n", m);
             // if a case has no break, 
             // it executes until it see a break or the end of switch
          case 10, 12, 3, 5, 7 : // multiple cases can share execution using comma (,)
             System.out.printf("Month %d has 31 days.\n", m);
             break;
          case 4, 6, 9, 11 :
             System.out.printf("Month %d has 30 days.\n", m);
             System.out.println("There are four months that have 30 days.");
             break;
          default : // default is optional but it is usually the last case
             System.out.printf("%d is not a valid month.\n", m);
             System.out.println("Month must be between 1 and 12.");
             break;
          case 2 :
             System.out.printf("Month %d has 28 or 29 days.\n", m);
       }

       // switch-case statement: ARROW CASE
       //    same as COLON CASE except that "break" is not used.
       // switch (EXPRESSION) {
       //    case CONSTANT_EXPRESSION ->
       //       ONE_STATEMENT_OR_ONE_BLOCK;
       // }
       var d = "Sunday";
       switch (d) {
          case "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" ->
             System.out.printf("%s is a weekday.\n", d);
          case "Saturday", "Sunday" -> {
             System.out.printf("%s is a holiday. ", d);
             System.out.println("No work during holidays.");
          }
          default -> System.out.printf("%s is not a valid day of week.", d);
       }
    }
    private static void demo05SwitchCaseExpression() {
       System.out.println("\nDemo06 Switch-Case Expression ===============");
    }
    private static void demo06ConditionalExpression() {
       System.out.println("\nDemo05 Conditional Expression ===============");
    }
}

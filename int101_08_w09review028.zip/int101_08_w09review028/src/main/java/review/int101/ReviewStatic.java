package review.int101;

public class ReviewStatic {

    public static double computeSphereVolume(double radius) {
        return 4.0 / 3.0 * Math.PI * radius * radius * radius;
    }

    public static double computeBoxVolume(double width, double height, double depth) {
        return width * height * depth;
    }

    public static double findMax(double v1, double v2, double v3) {
        var max = v1;
        if (max < v2) {
            max = v2;
        }
        if (max < v3) {
            max = v3;
        }
        return max;
    }

    public static double positiveSum(double v1, double v2, double v3, double v4) {
        if (v1 < 5.0) return 0;
        if (v2 < 5.0) return 0;
        if (v3 < 5.0) return 0;
        if (v4 < 5.0) return 0;
        return v1+v2+v3+v4 ;
    }
    
    //non finish
    public static double product(double v1, double v2 ,int step) {
        var result = 0;
        var i = v1;
        var count = v2;
        for (i = 0 ; i < count ; step++) {
            
        }
        return 0 ;
    }

}

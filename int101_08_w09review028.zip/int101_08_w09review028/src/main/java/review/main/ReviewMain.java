
package review.main;

import review.int101.ReviewStatic;

public class ReviewMain {
    public static void main(String[] args) {
        System.out.println("ComputeSphereVolume = " + ReviewStatic.computeSphereVolume(10));
        System.out.println("ComputeBoxVolume = " + ReviewStatic.computeBoxVolume(10, 25, 30));
    }
}

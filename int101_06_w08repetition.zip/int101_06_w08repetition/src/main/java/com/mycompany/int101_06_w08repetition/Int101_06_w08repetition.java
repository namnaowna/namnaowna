package com.mycompany.int101_06_w08repetition;

public class Int101_06_w08repetition {

    public static void main(String[] args) {
//        demoWhile();
//        demoDoWhile();
          demoForLoop();
        
    }

    private static void demoWhile() {
        int x = 0;
        int s = 0;
//        while (x == 1 ) System.out.println("NOTHING");
        while (x <= 10) { //while loop   
            s = s + x;
            System.out.println("s = " + s + ", x = " + x);
            if (x % 7 == 3) { // break , continute 
                continue;
            }
            x = x + 1;
//            if (x % 7 == 0) break;
        }
        System.out.println("sum of 0 to 10 = " + s);
        System.out.println("x = " + x);
    }

    private static void demoDoWhile() {
        int x = 0;
        int s = 0;
        do {
            s += ++x;
            if (x % 7 == 0) continue;
            System.out.println("s = " + s + ", x = " + x);
            
        }while(x < 10); 
        System.out.println("Finally, s = " + s + ", x = "+ x);
        
    }

    private static void demoForLoop() {
        // for , for each , functional for !!THIS STUDY FOR!!
        int s = 0;
        for (int x =1 ; x <= 10 ; x++) { 
            s += x;
//            if (x==5) continue; // break;
            System.out.println("s = " + s + ",x = " + x);
            
        }
        System.out.println("Finally s = " + s);
    }
    
    private static long factorial(long value) {
        
        
        return 0;
    }
    
    private static double summation(int start ,int stop ,int step) {
        
        
        return 0;
    }
}



package int101_10_w11review;
import int101.geometry.Box3D;
import int101.geometry.Sphere;
import int101.review.ReviewStatic;

public class Int101_10_w11review {
    public static void main(String[] args) {
//        System.out.println("SphereVolume = "+ReviewStatic.computerSphereVolume(5.0));
//        System.out.println("Find Max Value = " + ReviewStatic.findMax(2, 5, 3));
//        System.out.println("positive Sum = " + ReviewStatic.positiveSum(20, 4, 2, 6));
        
//        testSphere();
        testBox3D();
    }

    private static void testSphere() {
        Sphere s1 = new Sphere(5.0);
        Sphere s2 = new Sphere(10.0);
        System.out.println("s1 radius = " + s1.getRadius());
        System.out.println("s2 radius = " + s2.getRadius());
        System.out.println("s1 volume = " + s1.computeVolume());
        System.out.println("s1 surface = " + s1.computeSurface());
        System.out.println("s2 volume / s1 volume = " + s1.compareVolume(s2));
        s1.setRadius(2.5);
        System.out.println("s1 new radius = " + s1.getRadius());
        
        // TEST call static variable
        System.out.println("s1 color = " + s1.getColor());
        System.out.println("s2 color = " + s2.getColor());
        s1.setColor("RED");
        System.out.println("s1 Set color is RED");
        System.out.println("s1 color = " + s1.getColor());
        System.out.println("s2 color = " + s2.getColor());
        s2.setColor("GREEN");
        System.out.println("s2 Set color is GREEN");
        System.out.println("s1 color = " + s1.getColor());
        System.out.println("s2 color = " + s2.getColor());
        Sphere.setColor("BLUE");
        System.out.println("Sphere Set color is BLUE");
        System.out.println("Sphere color = " + Sphere.getColor());
        System.out.println("s1 color = " + s1.getColor());
        System.out.println("s2 color = " + s2.getColor());
        
        

        
    }

    private static void testBox3D() {
        
       Box3D.setLenght(5);
       Box3D.setColor("Red");
       System.out.println("Box3D Lenght = "+ Box3D.getLenght());
       System.out.println("Box3D Color = "+ Box3D.getColor());
       Box3D b1 = new Box3D(10,20);
       Box3D b2 = new Box3D(15,30);
       Box3D b3 = new Box3D(20,55);
//       System.out.println(b1);
//       System.out.println(b2);
//       System.out.println(b3);
       b1.setLenght(4);
       b1.setColor("White");
       System.out.println("b1 Lenght = " + b1.getLenght());
       System.out.println("b2 Color = " + b2.getColor());
       
       System.out.println(b1.toString());
       System.out.println(b2.toString());
       System.out.println(b3.toString());
       
       System.out.println("ComputeVolume ="+ b1.computeVolume());
       System.out.println("ComputeVolume ="+ b2.computeVolume());
       System.out.println("ComputeVolume ="+ b3.computeVolume());
       
       System.out.println(b2.canCover(b1));
       
       
       
       
       
    }
}


package int101.geometry;


public class Box3D {
    private double width;
    private double height;
    private static double lenght;
    private static String color;

    public Box3D(double width, double height) {
        this.width = width;
        this.height = height;
    }
    
    public double computeVolume (){
        return width * height * lenght;
    }
    
    public String canCover(Box3D b){
        if(this.width <= b.width) {
            if (this.height <= b.height) {
                return "Height is less";
            } return "Weight is less";
        }
        return "Can Cover";
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public static double getLenght() {
        return lenght;
    }

    public static void setLenght(double lenght) {
        Box3D.lenght = lenght;
    }

    public static String getColor() {
        return color;
    }

    public static void setColor(String color) {
        Box3D.color = color;
    }

    @Override
    public String toString() {
        return "Box3D{" + "width=" + width + ", height=" + height + ", lenght=" + lenght + '}';
    }
    
    
    
}


package int101.geometry;

public class Sphere {
    private double radius; // non-static field / instance varible
    private static String color;

    public static String getColor() {
        return color;
    }

    public static void setColor(String color) {
        Sphere.color = color;
        //color = variable(ANYONE); 
    }
    
    public Sphere(double radius) {
        this.radius = radius;
    }
    
    public double computeVolume() {
        return Math.PI * 4.0/3.0 * radius * radius * radius;
    }
    
    public double computeSurface() {
        return Math.PI * 4.0 * radius * radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }
    
    public double compareVolume(Sphere s) {
        return s.computeVolume() / this.computeVolume();
    }
    
}

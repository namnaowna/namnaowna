package int101.review;

// Utility class
public final class ReviewStatic { //This final is not subclass.

    public static double computerSphereVolume(double radius) {
        return Math.PI * 4.0/3.0 * radius * radius * radius;
    }

    public static double findMax(double v1, double v2, double v3) {
        double max = v1;
        max = max >= v2 ? max : v2;
        max = max >= v3 ? max : v3;

//        if (max >= v2 ) max = v2;
//        if (max >= v3 ) max = v3;
        return max;
    }

    public static double positiveSum(double v1, double v2, double v3, double v4) {
//        v1 = (v1 =  > 5) ? v1 : 0.0;
//        v2 = (v2 =  > 5) ? v2 : 0.0;
//        v3 = (v3 =  > 5) ? v3 : 0.0;
//        v4 = (v4 =  > 5) ? v4 : 0.0;

//        return 
//                setZeroIfLessthan5(v1)+
//                setZeroIfLessthan5(v2)+
//                setZeroIfLessthan5(v3)+
//                setZeroIfLessthan5(v4); 

        if (v1 < 5)  v1 = 0.0;
        if (v2 < 5)  v2 = 0.0;
        if (v3 < 5)  v3 = 0.0;
        if (v4 < 5)  v4 = 0.0;
        return v1 + v2 + v3 + v4;
    }
    
    private static final double setZeroIfLessthan5(double v) {
        return v > 5.0 ? v : 0.0;
    }

}

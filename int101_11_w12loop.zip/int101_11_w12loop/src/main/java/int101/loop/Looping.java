package int101.loop;

public final class Looping {

    public static String generating(int count) {
        String result = "";
        for (int i = 0, inc = 1, current = 0, step = 0; i < count; i++, step++) {
            if (step == 9) {
                result += "\n";
            }
            if (step == 10) {
                step = 1;
                inc *= 10;
            }
            current += inc;
            result += current + " ";
        }
        return result;
    }
}

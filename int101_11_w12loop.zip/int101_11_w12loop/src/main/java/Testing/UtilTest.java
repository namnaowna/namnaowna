package Testing;

import int101.loop.Looping;
import puzzle.Puzzle;

public class UtilTest {

    public static void main(String[] args) {
//        testGenerating();
        testPuzzle();
    }

    private static void testGenerating() {
        System.out.println("generating 40 :" + Looping.generating(40));
    }

    private static void testPuzzle() {
        double s = 0;
        int count = 100;
         for (int i = 0; i< count ; i++) {
             Puzzle p = new Puzzle();
             System.out.println(p.getValue());
             s += p.getValue();
         }
         System.out.println("Average = " + s/100);
    }
}

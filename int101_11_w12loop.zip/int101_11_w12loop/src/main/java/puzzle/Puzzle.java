
package puzzle;

import java.util.Random;

public class Puzzle {
    private final int value;
    
    public Puzzle() {
        value = (new Random()).nextInt(10);//(int)(10 * Math.random());
    }
    
    public int getValue(){
        return value;
    }
}

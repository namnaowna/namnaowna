
package mytest;

import tool.conversion.Convertor;
import tool.geometry.GeometryUtil;

public class ToolTest {
    public static void main(String[] args) {
//        geoTest();
        convertorTest();
    }
        
    private static void geoTest() {
        var radius = 5.0;
        double side1 = 3.0;
        double side2 = 5.0;
        System.out.printf("Area of Circle of %.2f = %.2f\n" ,radius , GeometryUtil.computeCircleArea(radius));
        System.out.printf("Perimeter of Circle of %.2f = %.2f\n" ,radius , GeometryUtil.computeCirclePerimeter(radius));
        System.out.printf("RightTriangleSide of %.2f and %.2f= %.2f\n" ,side1 ,side2, GeometryUtil.computeRightTriangleSide(side1, side2));
    }

    private static void convertorTest() {
        var inchToCm = new Convertor(2.54,"InchToCm");
        var kgToPound = new Convertor(2.20,"KgToPounds");
        var kgToMile = new Convertor(5.0/8.0);
        System.out.println(inchToCm);
        System.out.println(kgToPound);
        System.out.println(kgToMile);
        var kg = 5.0;
        var lbs = 220.0;
        System.out.printf("From %.2f Kg to Pound = %.2f\n",kg , kgToPound.convert(kg));
        System.out.printf("From %.2f Pound to Kg = %.2f\n",lbs, kgToPound.invert(lbs));
        
    }
        
    
    
    
}

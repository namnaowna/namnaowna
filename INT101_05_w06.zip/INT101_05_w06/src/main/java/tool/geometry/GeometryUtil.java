
package tool.geometry;

public class GeometryUtil {
    // computeCircleArea -> input radius (double) , output -> area (double)
    // computeCirclePerimeter -> input radius (double) , output -> perimeter (double)
    // computeRightTriangleSide -> input two sides of RightTriangle (double) , output -> oppsite side of the right angel 
    
    public static double computeCircleArea(double radius) {
        return Math.PI * radius * radius;
    }
    
    public static double computeCirclePerimeter(double radius) {
        return 2.0 * Math.PI * radius ;
    }
    
    public static double computeRightTriangleSide(double side1,double side2) {
        return Math.sqrt(side1 * side1 + side2 * side2) ;
    }
    
}

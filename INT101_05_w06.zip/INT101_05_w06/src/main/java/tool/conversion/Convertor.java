
package tool.conversion;

public class Convertor {
    private final double ratio;
    private final String name;
    
//    // constructor -- create object , !!Not retrun type
//    // empty constructor
    
//    public Convertor() {
//        ratio = 0.0;
//        name = ""; //empty String
//    }

    // constructor
    /// Overload Method
    public Convertor(double ratio, String name) {
        this.ratio = ratio;
        this.name = name == null ? "Noname" : name;
    }
    
    public Convertor(double ratio) {
        this.ratio = ratio;
        this.name = "Noname";
    }
    
    // getter
    public double getRatio() { return ratio; }
    public String getName() { return name; }
    
    
   // functions
    public double convert(double from) { return from * ratio; }    
    public double invert(double from) { return from / ratio; }

    @Override
    public String toString() {
        return "Convertor{" + "ratio=" + ratio + ", name=" + name + '}';
    }
    
    
    


    
    
    
   
    
    
    
}

// Non object
public class FindArea {
    
    public static void main(String[] args) {
        double width = 5.0;
        double lenght = 10.2;
         printResult("Area of Rectangle %.1f x %.1f = %.2f%n" //format printing
                ,width ,lenght , computeArea(width, lenght));
         width = 4.5;
         lenght = 3.7;
         printResult("Area of Rectangle %.1f x %.1f = %.2f%n" //format printing
                ,width ,lenght , computeArea(width, lenght));
         printHello();
    }
    
    public static void printResult(String s,double a, double b, double c) {
        System.out.printf(s, a, b, c);
        
    }
    
    public static double computeArea(double width, double lenght) { //method
        return width * lenght; 
    }
    
    public static void printHello() {
        System.out.println("Hello");
        
    }
    
    
    
    
    
    // **TYPE DATA**
    // boolean = true , false
    // siagned number = integer , floating-point number
    //     integer = byte , short , *int* , long
    //     floating-point number = float , *double*
    // (unsigned number)character = char 
    // null
}
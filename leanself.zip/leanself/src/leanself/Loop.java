
package leanself;

public class Loop {
    public static void main(String[] args) {
        //ข้อ 1 แสดงตัวเลขตั้งแต่ 11 ถึง 20
//        for (int i = 11; i <= 20 ; i++) {
//            System.out.println(i);
//        }
        
        //ข้อ 2 หาผลรวมของตัวเลขตั้งแต่ 2 ถึง 12
//        int sumNumber = 0;
//        
//        for (int i =2 ; i<=12 ; i++) {
//            sumNumber += i;
//        }
//        System.out.println(sumNumber);
        
        //ข้อ 3 หาผลรวมของเลขคู่ในช่วง 1 ถึง 10 
//        int sumNumber = 0;
//        
//        for (int i = 1 ; i <= 10 ; i++) {
//            if (i % 2 != 0) {
//                continue; //เจอใน Loop ใช้ข้าม
//            }
//            sumNumber += i;
//        }
//        System.out.println(sumNumber);
        
        //ข้อ 4 หาผลรวมของเลขตั้งแต่ 2 ถึง 22 ถ้าเจอเลข ที่ลงท้ายด้วย 0 เมื่อไหร่ ให้หยุดคำนวณและออกจากลูปทันที
        int sumNumber = 0;
        
        for (int i = 2 ; i <= 22 ; i++) {
            if (i % 10 == 0) {
                break; //คำสั่งออกจาก Loop
            }
            sumNumber += i;
        }
        System.out.println(sumNumber);
        
        
        
    }
    
}

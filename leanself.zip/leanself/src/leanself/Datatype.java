
package leanself;

public class Datatype {
//    public static void main(String[] args) {
//        double grade = 2.15; //เก็บค่าเป็นทศนิยม
//        String name = "028"; //เก็บค่าเป็นข้อความ
//        boolean isLogin = false; //เก็บได้แค่สองค่า True หรือ False
//    }
    public static void main(String[] args) {
        
        //ข้อ 1
//        double latitude = 13.5555;
//        double Longitude = 100.5555;
//        String outputText = "(" + latitude + "," + Longitude + ")";
//        System.out.println(outputText);

        //ข้อ2
//          String numberText = "23";
//          int number = Integer.parseInt(numberText); //เปลี่ยน text เป็น ตัวเลข
//          System.out.println(number + 5);

        //ข้อ3
          String numberText = "23.75";
          double number = Double.parseDouble(numberText); //เปลี่ยน text เป็น ตัวเลข
          System.out.println(number + 5);
    }
}


package leanself;

public class Operators {
    public static void main(String[] args) {
        //เครื่องหมายคำนวณตัวเลข
        // ข้อ 1 บวก ลบ คูณ หาร หารหาเศษ
//        double firstNumber = 15;
//        double secondNumber = 4;
//        System.out.println(firstNumber + secondNumber);
//        System.out.println(firstNumber - secondNumber);
//        System.out.println(firstNumber * secondNumber);
//        System.out.println(firstNumber / secondNumber);
//        System.out.println(firstNumber % secondNumber);

        // ข้อ 2 บวกบวก ลบลบ บวกเท่ากับ หารเท่ากับ(Shortcut)
//        double firstName = 15;
////        firstName++; //บวกเพิ่มไป 1
////        firstName--; //ลบไป 1
////        firstName+= 3; //บวกเพิ่มไปอีก 3
//        firstName /= 2; //หารกับ 2
//        System.out.println(firstName);

        
         //เครื่องหมายคำนวณเปรียบเทียบ
         //ข้อ 1 มากกว่า น้อยกว่า เท่ากับ ไม่เท่ากับ (เปรียบเทียบตัวเลข) > < >= <= == !=
//            double firstNumber = 10;
//            double secondNumber = 15;
//            System.out.println(firstNumber > secondNumber);
//            System.out.println(firstNumber < secondNumber);
//            System.out.println(firstNumber >= secondNumber);
//            System.out.println(firstNumber <= secondNumber);
//            System.out.println(firstNumber == secondNumber);
//            System.out.println(firstNumber != secondNumber);


         //ข้อ 2 AND OR NOT (ตรรกศาสตร์)
         boolean isUsernameCorrect = true;
         boolean isPasswordCorrect = false;
         System.out.println(isUsernameCorrect && isPasswordCorrect);
         System.out.println(isUsernameCorrect || isPasswordCorrect);
         System.out.println(!isUsernameCorrect);
         
         
    }
    
}

package leanself;

public class Conditions {
    public static void main(String[] args) {
    double originalPrice = 20000;
    double finalPrice = originalPrice;

    if (originalPrice >= 10000) {
        finalPrice = originalPrice - 0.15 * originalPrice; //(0.15 * originalPrice) ราคาส่วนลด 15% 
    } else if (originalPrice >= 6000 ) {
        finalPrice = originalPrice - 0.10 * originalPrice;
    } else if (originalPrice >= 3000 ) {
        finalPrice = originalPrice - 0.08 * originalPrice;
    } else {
        finalPrice = originalPrice - 0.05 * originalPrice;
    }
    
        System.out.println(finalPrice);
    }
   
   
}


package leanself;

public class Variables {
    public static void main(String[] args) {
        int height = 154;
        System.out.println(height);
        int weight = 44;
        System.out.println(weight);
    }
}

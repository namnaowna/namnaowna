
public class BoxV2 {

    private double w, h, d; // access modifier
    // data + method

    //Constructor
    public BoxV2(double w, double h, double d) {
//        this.w = w;
        setW(w);
        this.h = h;
        this.d = d;
    }

    // default constructor
    public BoxV2() {

    }

    // setter
    public void setW(double w) {
        if (w > 0.0) {
            this.w = w;
        } else {
//          throw new IllegalArgrumentException("ค่าความกว้างจะต้องมากกว่าศูนย์");
            System.out.println("w > 0");
        }
    }

    public void setH(double h) {
        if (h > 0.0) {
            this.h = h;
        } else {
            System.out.println("ค่าความสูงจะต้องมากกว่าศูนย์");
        }
    }

    public void setD(double d) {
        if (d > 0.0) {
            this.d = d;
        } else {
            System.out.println("ค่าความยาวจะต้องมากกว่าศูนย์");
        }
    }

    // getter
    public double getW() {
        return w;
    }

    // function
    public double volume() {
        return w * h * d;
    }

    public double surfaceArea() {
        return (2.0 * w * h) + (2.0 * w * d) + (2.0 * d * h);
    }
    
    //// annotation
    //toString
    @Override
    public String toString() {
//        return "BoxV2{" + "w=" + w + ", h=" + h + ", d=" + d + '}';
//        return String.format("width = % .2f, height = %.2f , depth = %.2f",w,h,d);
          return String.format("Size %.2f x %.2f x %.2f , volume = %.2f",w,h,d,volume());
          
        
    }
    
}


public class Main {
    public static void main(String[] args) {
        
        BoxV1 aBox = new BoxV1();
        aBox.d = 10.0;
        aBox.w = 5.0;
        aBox.h = 7.0;
        System.out.println("Box1 ="+ aBox.volume());
        System.out.println("Box1 ="+ aBox.surfaceArea());
        
        // get Constructor
        BoxV2 aBox2 = new BoxV2(120,10,6);
        System.out.println("Box2 ="+ aBox2.volume());
        System.out.println("Box2 ="+ aBox2.surfaceArea());
        
        BoxV2 aBox2a = new BoxV2();
        System.out.println("Box2a ="+ aBox2a.volume());
        System.out.println("Box2a ="+ aBox2a.surfaceArea());
        
        if (aBox2.getW() > 100.0) {
            System.out.println("Box is BIG");
        }
        
        //get toString
        System.out.println(aBox2);
        System.out.println(aBox2.toString());
        
//        ฺBoxV2 aBox2 = new BoxV2();
//        aBox2.setD(10.0);
//        aBox2.setW(5.0);
//        aBox2.setH(7.0);
//        System.out.println(aBox2.volume());
//        System.out.println(aBox2.surfaceArea());

        
    }

    

    
}

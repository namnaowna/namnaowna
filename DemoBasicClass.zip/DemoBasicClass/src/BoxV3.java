
public class BoxV3 {

    private double w, h, d; //fields

    public BoxV3() {
    }

    public BoxV3(double w, double h, double d) {
        this.w = w;
        this.h = h;
        this.d = d;
    }

    @Override
    public String toString() {
        return "BoxV3{" + "w=" + w + ", h=" + h + ", d=" + d + '}';
    }

    public double getW() {
        return w;
    }

    public double getH() {
        return h;
    }

    public double getD() {
        return d;
    }

    public void setW(double w) {
        this.w = w;
    }

    public void setH(double h) {
        this.h = h;
    }

    public void setD(double d) {
        this.d = d;
    }

    // function
    public double volume() {
        return w * h * d;
    }

    public double surfaceArea() {
        return (2.0 * w * h) + (2.0 * w * d) + (2.0 * d * h);
    }

}

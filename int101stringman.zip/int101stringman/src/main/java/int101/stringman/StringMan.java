

package int101.stringman;

public class StringMan {
    private int x;
    private int y;
    
    // toString() builder
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("StringMan{");
        sb.append("x=").append(x);
        sb.append(", y=").append(y);
        sb.append('}');
        return sb.toString();
    }
    

    public static void main(String[] args) {
        demoStringConcar();
    }

    private static void demoStringConcar() {
        var a = "x";
        var b = "y";
        var c = "xy";
        var d = "x";
        System.out.println("a == d? " + (a == d));
        System.out.println("a.equal(d) ? " + (a.equals(d))); //same address
        System.out.println("c == (a+b?).intern() " + (c == (a+b).intern())); // add .intern() result this true 
        System.out.println("c.equal(a+b) ? " + (c.equals(a+b)));
        var m = new String("z");
        var n = "z";
        System.out.println("m == n ? " + (m == n));
        System.out.println("m.intern() == n ? " + (m.intern() == n));
//        m = m.intern();
        System.out.println("m == n ? " + (m == n));
}
}
